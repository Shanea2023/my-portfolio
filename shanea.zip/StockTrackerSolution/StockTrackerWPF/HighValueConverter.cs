﻿using System;
using System.Windows.Controls;
using System.Windows.Data;
using System.Globalization;
using StockDataLibrary;

namespace StockTrackerWPF
{
    public class HighValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is DataGridRow row && row.Item is StockData stock) // Replace StockItem
            {
                return stock.High > stock.Open * 1.05;
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}