﻿using StockDataLibrary;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace StockTrackerWPF
{
    public class StockViewModel
    {
        private readonly StockApiService _apiService;
        private readonly List<string> _symbols;
        private bool _isSortedDescending = true;

        public ObservableCollection<StockData> StockItems { get; } = new ObservableCollection<StockData>();

        public StockViewModel()
        {
            _apiService = new StockApiService("HEV0TBQBY5N7AR7N");
            _symbols = new List<string> { "IBM", "AAPL", "TSLA" };
            StartFetchingData();
        }

        public void AddSymbol(string symbol)
        {
            if (!_symbols.Contains(symbol.ToUpper()))
            {
                _symbols.Add(symbol.ToUpper());
            }
        }

        public void SortByVolume()
        {
            _isSortedDescending = !_isSortedDescending;
            ApplySort();
        }

        private void ApplySort()
        {
            var sortedItems = _isSortedDescending
                ? StockItems.OrderByDescending(s => s.Volume).ToList()
                : StockItems.OrderBy(s => s.Volume).ToList();

            StockItems.Clear();
            foreach (var item in sortedItems)
            {
                StockItems.Add(item);
            }
        }

        private async void StartFetchingData()
        {
            while (true)
            {
                var tasks = _symbols.Select(symbol => _apiService.FetchStockData(symbol)).ToList();
                var results = await Task.WhenAll(tasks);
                Application.Current.Dispatcher.Invoke(() =>
                {
                    foreach (var stockDataList in results)
                    {
                        if (stockDataList.Count > 0)
                        {
                            var latestData = stockDataList.Take(5);
                            foreach (var item in latestData)
                            {
                                var existing = StockItems.FirstOrDefault(x => x.Equals(item));
                                if (existing != null)
                                {
                                    existing.Open = item.Open;
                                    existing.High = item.High;
                                    existing.Low = item.Low;
                                    existing.Close = item.Close;
                                    existing.Volume = item.Volume;
                                }
                                else
                                {
                                    StockItems.Add(item);
                                }
                            }
                        }
                    }
                    ApplySort();
                });
                await Task.Delay(60000);
            }
        }

        public bool IsSortedDescending => _isSortedDescending;
    }
}