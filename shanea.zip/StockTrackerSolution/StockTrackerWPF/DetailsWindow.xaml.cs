﻿using LiveCharts;
using LiveCharts.Wpf;
using StockDataLibrary;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace StockTrackerWPF
{
    public partial class DetailsWindow : Window
    {
        private readonly StockViewModel _viewModel;
        private readonly string _symbol;

        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> Formatter { get; set; }

        public DetailsWindow(StockViewModel viewModel, string symbol)
        {
            InitializeComponent();
            _viewModel = viewModel;
            _symbol = symbol.ToUpper();

            // Set up chart
            SetupChart();
            DataContext = this;

            // Update UI with initial data
            UpdateStockInfo();

            // Subscribe to StockItems changes
            _viewModel.StockItems.CollectionChanged += StockItems_CollectionChanged;
        }

        private void SetupChart()
        {
            SeriesCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Close Price",
                    Values = new ChartValues<double>(),
                    PointGeometrySize = 10,
                    Stroke = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(52, 152, 219)), // #3498DB
                    Fill = System.Windows.Media.Brushes.Transparent
                }
            };

            Labels = new string[0];
            Formatter = value => value.ToString("F2");
            UpdateChartData();
        }

        private void UpdateStockInfo()
        {
            var stockData = _viewModel.StockItems.Where(s => s.Symbol == _symbol).OrderByDescending(s => s.Date).FirstOrDefault();
            if (stockData != null)
            {
                HeaderText.Text = $"{_symbol} Details";
                SymbolText.Text = $"Symbol: {_symbol}";
                PriceText.Text = $"Latest Close: ${stockData.Close:F2}";
                VolumeText.Text = $"Volume: {stockData.Volume:N0}";
            }
        }

        private void UpdateChartData()
        {
            var recentData = _viewModel.StockItems.Where(s => s.Symbol == _symbol)
                                                  .OrderBy(s => s.Date)
                                                  .Take(5)
                                                  .ToList();
            if (recentData.Any())
            {
                SeriesCollection[0].Values.Clear();
                foreach (var data in recentData)
                {
                    SeriesCollection[0].Values.Add(data.Close);
                }
                Labels = recentData.Select(d => d.Date).ToArray();
            }
        }

        private void StockItems_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            UpdateStockInfo();
            UpdateChartData();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


    }
}