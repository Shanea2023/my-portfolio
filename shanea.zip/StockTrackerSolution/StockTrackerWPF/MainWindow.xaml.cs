﻿using StockDataLibrary;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace StockTrackerWPF
{
    public partial class MainWindow : Window
    {
        private readonly StockViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            _viewModel = new StockViewModel();
            DataContext = _viewModel;

            // Verify UI elements exist
            System.Diagnostics.Debug.WriteLine($"SearchButton: {SearchButton != null}, SortButton: {SortButton != null}, DetailsButton: {DetailsButton != null}, StockGrid: {StockGrid != null}");
            SortButton.Content = _viewModel.IsSortedDescending ? "Sort ↓" : "Sort ↑";

            // Check initial StockItems
            _viewModel.StockItems.CollectionChanged += (s, e) =>
                System.Diagnostics.Debug.WriteLine($"StockItems Count: {_viewModel.StockItems.Count}");
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string symbol = SearchBox.Text.Trim().ToUpper();
            if (!string.IsNullOrWhiteSpace(symbol))
            {
                _viewModel.AddSymbol(symbol);
                SearchBox.Text = "";
                System.Diagnostics.Debug.WriteLine($"Search Added: {symbol}");
            }
        }

        private void SortButton_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.SortByVolume();
            SortButton.Content = _viewModel.IsSortedDescending ? "Sort ↓" : "Sort ↑";
            System.Diagnostics.Debug.WriteLine($"Sort Toggled: IsDescending = {_viewModel.IsSortedDescending}");
        }

        private void DetailsButton_Click(object sender, RoutedEventArgs e)
        {
            if (StockGrid.SelectedItem is StockData selectedStock)
            {
                var detailsWindow = new DetailsWindow(_viewModel, selectedStock.Symbol);
                detailsWindow.Show();
                System.Diagnostics.Debug.WriteLine($"Details Opened: {selectedStock.Symbol}");
            }
            else
            {
                MessageBox.Show("Please select a stock to view details.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        
    }
    
}