﻿using StockDataLibrary;
using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Controls;

namespace StockTrackerWPF
{
    public class LowValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is DataGridRow row && row.Item is StockData stock)
            {
                // Highlight if Low is 5% below Open
                bool isLow = stock.Low < stock.Open * 0.95;
                System.Diagnostics.Debug.WriteLine($"Stock {stock.Symbol}: Open = {stock.Open}, Low = {stock.Low}, IsLow = {isLow}");
                return isLow;
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}