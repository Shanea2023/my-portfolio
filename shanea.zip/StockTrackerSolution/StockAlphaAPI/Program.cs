﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using StockDataLibrary;

namespace StockAlphaAPI
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            var apiService = new StockApiService("HEV0TBQBY5N7AR7N"); // Key unused with mock data
            List<string> symbols = new List<string>();

            Console.WriteLine("Enter stock symbols (e.g., IBM, AAPL, TSLA). Type 'done' when finished:");
            while (true)
            {
                string input = Console.ReadLine()?.Trim().ToUpper();
                if (input == "DONE") break;
                if (!string.IsNullOrWhiteSpace(input)) symbols.Add(input);
            }

            if (symbols.Count == 0)
            {
                Console.WriteLine("No symbols entered. Using defaults: IBM, AAPL, TSLA.");
                symbols.AddRange(new[] { "IBM", "AAPL", "TSLA" });
            }

            Console.WriteLine($"Starting real-time stock tracking for {string.Join(", ", symbols)}...");

            while (true)
            {
                var tasks = symbols.Select(symbol => apiService.FetchStockData(symbol)).ToList();
                var results = await Task.WhenAll(tasks);
                foreach (var stockDataList in results)
                {
                    if (stockDataList.Count > 0)
                    {
                        var latestData = stockDataList[0];
                        Console.WriteLine($"{latestData.Symbol} - " +
                                          $"Open: ${latestData.Open:F2}  " +
                                          $"High: ${latestData.High:F2}  " +
                                          $"Low: ${latestData.Low:F2}  " +
                                          $"Close: ${latestData.Close:F2}  " +
                                          $"Volume: {latestData.Volume}  " +
                                          $"Time: {latestData.Date}");
                    }
                    else
                    {
                        Console.WriteLine($"No data received.");
                    }
                }
                Console.WriteLine("Updating in 60 seconds...");
                await Task.Delay(60000);
            }
        }
    }
}