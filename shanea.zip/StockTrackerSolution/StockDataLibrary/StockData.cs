﻿namespace StockDataLibrary
{
    public class StockData
    {
        public string Symbol { get; set; }
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Close { get; set; }
        public int Volume { get; set; }
        public string Date { get; set; }

        // Add for WPF binding comparison
        public override bool Equals(object obj)
        {
            if (obj is StockData other)
            {
                return Symbol == other.Symbol && Date == other.Date;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Symbol, Date);
        }
    }
}