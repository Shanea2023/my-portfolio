﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;

namespace StockDataLibrary
{
    public class StockApiService
    {
        private readonly string _apiKey; // Kept for consistency, though unused with mock data

        public StockApiService(string apiKey)
        {
            _apiKey = apiKey;
        }

        public async Task<List<StockData>> FetchStockData(string symbol)
        {
            // Mock CSV data simulating Alpha Vantage response
            string mockCsv = "timestamp,open,high,low,close,volume\n" +
                             $"{DateTime.Now:yyyy-MM-dd HH:mm:ss},{RandomPrice(150)},{RandomPrice(152)},{RandomPrice(149)},{RandomPrice(151)},{RandomVolume()}\n" +
                             $"{DateTime.Now.AddMinutes(-1):yyyy-MM-dd HH:mm:ss},{RandomPrice(149)},{RandomPrice(151)},{RandomPrice(148)},{RandomPrice(150)},{RandomVolume()}\n" +
                             $"{DateTime.Now.AddMinutes(-2):yyyy-MM-dd HH:mm:ss},{RandomPrice(148)},{RandomPrice(150)},{RandomPrice(147)},{RandomPrice(149)},{RandomVolume()}";

            // Simulate async behavior
            await Task.Delay(100); // Mimic network delay
            return ParseCsvData(mockCsv, symbol);
        }

        private double RandomPrice(double basePrice)
        {
            return basePrice + (new Random().NextDouble() * 2 - 1); // ±1 variation
        }

        private int RandomVolume()
        {
            return new Random().Next(90000, 110000); // 90k-110k shares
        }

        private List<StockData> ParseCsvData(string csvData, string symbol)
        {
            if (string.IsNullOrWhiteSpace(csvData) || !csvData.Contains("timestamp"))
            {
                Console.WriteLine($"Invalid CSV data received for {symbol}: {csvData}");
                return new List<StockData>();
            }

            using (TextReader reader = new StringReader(csvData))
            using (CsvReader csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var data = new List<StockData>();
                csv.Read();
                csv.ReadHeader();
                while (csv.Read())
                {
                    data.Add(new StockData
                    {
                        Symbol = symbol,
                        Open = csv.GetField<double>("open"),
                        High = csv.GetField<double>("high"),
                        Low = csv.GetField<double>("low"),
                        Close = csv.GetField<double>("close"),
                        Volume = csv.GetField<int>("volume"),
                        Date = DateTime.Parse(csv.GetField<string>("timestamp")).ToString("MM-dd-yyyy HH:mm")
                    });
                }
                return data;
            }
        }
    }
}