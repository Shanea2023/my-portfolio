import sqlite3
from passlib.hash import bcrypt

DATABASE = 'database.db'

def create_users_table():
    """
    Tạo bảng users (nếu chưa tồn tại) với các cột:
      - id (PRIMARY KEY)
      - username (UNIQUE)
      - password (lưu chuỗi hash)
      - email (tuỳ chọn)
      - role (Customer/Admin)
    """
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT,
            role TEXT NOT NULL DEFAULT 'Customer'
        )
    ''')
    conn.commit()
    conn.close()
    print("Users table ensured with columns: id, username, password, email, role.")

def add_user(username, password, email=None, role="Customer"):
    """
    Thêm user mới vào bảng users.
      - username: tên đăng nhập (unique)
      - password: chuỗi plaintext (sẽ được hash trước khi lưu)
      - email: địa chỉ email (tuỳ chọn)
      - role: vai trò (mặc định là 'Customer')

    Trả về:
      - new_id: id của user mới tạo nếu thành công
      - None nếu thất bại (ví dụ: trùng username hoặc lỗi DB)
    """
    try:
        # Hash mật khẩu trước khi lưu
        hashed_password = bcrypt.hash(password)
        
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute('''
            INSERT INTO users (username, password, email, role)
            VALUES (?, ?, ?, ?)
        ''', (username, hashed_password, email, role))
        conn.commit()
        new_id = c.lastrowid
        conn.close()
        return new_id
    except sqlite3.IntegrityError:
        print("Error: Username already exists.")
        return None
    except Exception as e:
        print("Unexpected Error in add_user:", e)
        return None

def get_user_by_username(username):
    """
    Lấy thông tin user theo username.
    Trả về:
      - dict {id, username, password, email, role} nếu tìm thấy
      - None nếu không tìm thấy
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute('''
            SELECT id, username, password, email, role
            FROM users
            WHERE username = ?
        ''', (username,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'username': row[1],
                'password': row[2],  # chuỗi hash
                'email': row[3],
                'role': row[4]
            }
        return None
    except Exception as e:
        print("Error in get_user_by_username:", e)
        return None

def get_user_by_id(user_id):
    """
    Lấy thông tin user theo id.
    Trả về:
      - dict {id, username, password, email, role} nếu tìm thấy
      - None nếu không tìm thấy
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute('''
            SELECT id, username, password, email, role
            FROM users
            WHERE id = ?
        ''', (user_id,))
        row = c.fetchone()
        conn.close()
        if row:
            return {
                'id': row[0],
                'username': row[1],
                'password': row[2],  # chuỗi hash
                'email': row[3],
                'role': row[4]
            }
        return None
    except Exception as e:
        print("Error in get_user_by_id:", e)
        return None

def verify_password(plain_password, hashed_password):
    """
    Kiểm tra mật khẩu plaintext với mật khẩu hash trong DB.
    Trả về True nếu khớp, False nếu không.
    """
    try:
        return bcrypt.verify(plain_password, hashed_password)
    except Exception as e:
        print("Error in verify_password:", e)
        return False
