import sqlite3

DATABASE = 'database.db'

def create_menus_table():
    """
    Create the menus table with fields for id, name, price, description, and image.
    """
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS menus (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            image TEXT
        )
    ''')
    conn.commit()
    conn.close()

def add_menu(name, price, description=None, image=None):
    """
    Add a new menu item to the database.
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute('''
            INSERT INTO menus (name, price, description, image)
            VALUES (?, ?, ?, ?)
        ''', (name, price, description, image))
        conn.commit()
        new_id = c.lastrowid
        conn.close()
        return new_id
    except sqlite3.Error as e:
        print(f"Error adding menu: {e}")
        return None

def get_all_menus():
    """
    Retrieve all menu items.
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT id, name, price, description, image FROM menus")
        rows = c.fetchall()
        conn.close()

        return [
            {'id': row[0], 'name': row[1], 'price': row[2], 'description': row[3], 'image': row[4]}
            for row in rows
        ]
    except sqlite3.Error as e:
        print(f"Error retrieving menus: {e}")
        return []

def get_menu_by_id(menu_id):
    """
    Retrieve menu details by ID.
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("""
            SELECT id, name, price, description, image
            FROM menus
            WHERE id = ?
        """, (menu_id,))
        row = c.fetchone()
        conn.close()

        if row:
            return {'id': row[0], 'name': row[1], 'price': row[2], 'description': row[3], 'image': row[4]}
        return None
    except sqlite3.Error as e:
        print(f"Error retrieving menu by ID: {e}")
        return None

def update_menu(menu_id, name, price, description, image=None):
    """
    Update menu details.
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        if image is not None:
            c.execute('''
                UPDATE menus
                SET name = ?, price = ?, description = ?, image = ?
                WHERE id = ?
            ''', (name, price, description, image, menu_id))
        else:
            c.execute('''
                UPDATE menus
                SET name = ?, price = ?, description = ?
                WHERE id = ?
            ''', (name, price, description, menu_id))
        conn.commit()
        updated = (c.rowcount > 0)
        conn.close()
        return updated
    except sqlite3.Error as e:
        print(f"Error updating menu: {e}")
        return False

def delete_menu(menu_id):
    """
    Delete a menu item by ID.
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("DELETE FROM menus WHERE id = ?", (menu_id,))
        conn.commit()
        deleted = (c.rowcount > 0)
        conn.close()
        return deleted
    except sqlite3.Error as e:
        print(f"Error deleting menu: {e}")
        return False

def search_menus_by_name(keyword):
    """
    Search for menu items by name.
    """
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("""
            SELECT id, name, price, description, image
            FROM menus
            WHERE name LIKE ?
        """, ('%' + keyword + '%',))
        rows = c.fetchall()
        conn.close()

        return [
            {'id': row[0], 'name': row[1], 'price': row[2], 'description': row[3], 'image': row[4]}
            for row in rows
        ]
    except sqlite3.Error as e:
        print(f"Error searching menus: {e}")
        return []
