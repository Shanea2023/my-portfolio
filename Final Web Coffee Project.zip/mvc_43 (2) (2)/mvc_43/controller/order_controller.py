from flask import Blueprint, render_template, session, flash, redirect, url_for, request

order_bp = Blueprint('order_bp', __name__)

# Giả lập dữ liệu đơn hàng (thay thế bằng database trong thực tế)
orders = [
    {
        'id': 1,
        'customer': 'John Doe',
        'created_at': '2025-01-13',
        'total': 123.45,
        'status': 'Pending',
        'items': [
            {'name': 'Espresso', 'price': 50.0, 'quantity': 1},
            {'name': 'Latte', 'price': 73.45, 'quantity': 1},
        ]
    },
    {
        'id': 2,
        'customer': 'Jane Smith',
        'created_at': '2025-01-12',
        'total': 89.99,
        'status': 'Confirmed',
        'items': [
            {'name': 'Americano', 'price': 89.99, 'quantity': 1},
        ]
    }
]

# Route: Quản lý đơn hàng
@order_bp.route('/manage', methods=['GET'])
def manage_orders():
    """
    Trang quản lý đơn hàng dành cho admin.
    """
    if session.get('user_role') != 'Admin':
        flash("You do not have permission to access this page.", "danger")
        return redirect(url_for('home'))
    
    return render_template('order/manage.html', orders=orders)

# Route: Xem chi tiết đơn hàng
@order_bp.route('/view/<int:order_id>', methods=['GET'])
def view_order(order_id):
    """
    Xem chi tiết đơn hàng.
    """
    if session.get('user_role') != 'Admin':
        flash("You do not have permission to access this page.", "danger")
        return redirect(url_for('home'))

    # Tìm đơn hàng theo ID
    order = next((order for order in orders if order['id'] == order_id), None)
    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for('order_bp.manage_orders'))
    
    return render_template('order/view.html', order=order)

# Route: Xác nhận đơn hàng
@order_bp.route('/confirm/<int:order_id>', methods=['POST'])
def confirm_order(order_id):
    """
    Xác nhận đơn hàng.
    """
    if session.get('user_role') != 'Admin':
        flash("You do not have permission to access this page.", "danger")
        return redirect(url_for('order_bp.manage_orders'))
    
    # Tìm đơn hàng và cập nhật trạng thái
    order = next((order for order in orders if order['id'] == order_id), None)
    if not order:
        flash("Order not found.", "danger")
    else:
        if order['status'] == 'Pending':
            order['status'] = 'Confirmed'
            flash(f"Order #{order_id} has been confirmed.", "success")
        else:
            flash(f"Order #{order_id} is already confirmed.", "info")

    return redirect(url_for('order_bp.manage_orders'))

# Route: Xóa đơn hàng
@order_bp.route('/delete/<int:order_id>', methods=['POST'])
def delete_order(order_id):
    """
    Xóa đơn hàng.
    """
    if session.get('user_role') != 'Admin':
        flash("You do not have permission to access this page.", "danger")
        return redirect(url_for('order_bp.manage_orders'))
    
    global orders
    updated_orders = [order for order in orders if order['id'] != order_id]
    
    if len(updated_orders) == len(orders):
        flash("Order not found.", "danger")
    else:
        orders.clear()
        orders.extend(updated_orders)
        flash(f"Order #{order_id} has been deleted.", "success")
    
    return redirect(url_for('order_bp.manage_orders'))

# Route: Hiển thị thành công đơn hàng
@order_bp.route('/success', methods=['POST'])
def order_success():
    """
    Hiển thị trang thông báo Order thành công.
    """
    session.pop('cart', None)
    flash("Order Successful! Thank you for your purchase.", "success")
    return render_template('order/success.html')

@order_bp.route('/buy', methods=['POST'])
def place_order():
    """
    Người dùng ấn "Buy" để đặt hàng.
    """
    if 'cart' not in session or not session['cart']:
        flash("Your cart is empty.", "danger")
        return redirect(url_for('menu_bp.view_cart'))

    global orders  # Sử dụng danh sách giả lập `orders` để lưu đơn hàng

    # Tạo đơn hàng mới từ giỏ hàng
    new_order = {
        'id': len(orders) + 1,  # Tăng ID tự động
        'customer': session.get('user_name', 'Guest'),  # Tên người dùng (hoặc 'Guest')
        'created_at': '2025-01-13',  # Ngày tạo đơn hàng (dùng datetime trong thực tế)
        'total': sum(item['price'] * item['quantity'] for item in session['cart']),
        'status': 'Pending',  # Trạng thái ban đầu là 'Pending'
        'items': session['cart']  # Lấy các mặt hàng từ giỏ hàng
    }

    # Lưu đơn hàng vào danh sách
    orders.append(new_order)

    # Xóa giỏ hàng sau khi đặt hàng
    session.pop('cart', None)

    flash(f"Order #{new_order['id']} has been placed successfully!", "success")
    return redirect(url_for('order_bp.manage_orders'))