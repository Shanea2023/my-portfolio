# controller/search_controller.py
from flask import Blueprint, request, render_template
from model.menu_model import search_menus_by_name

search_bp = Blueprint('search_bp', __name__)

@search_bp.route('/', methods=['GET'])
def search():
    """
    Lấy query param 'q', tìm menu theo tên, trả về kết quả.
    Ví dụ: /search?q=latte
    """
    query = request.args.get('q', '').strip()
    results = []
    if query:
        # Gọi hàm tìm kiếm trong menu_model (hoặc mở rộng sang các model khác)
        results = search_menus_by_name(query)
    
    # Render template search/results.html
    return render_template('search/results.html', query=query, results=results)
