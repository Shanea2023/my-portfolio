from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from model.user_model import add_user, get_user_by_username, get_user_by_id, verify_password

user_bp = Blueprint('user_bp', __name__)

def admin_required(func):
    """
    Decorator kiểm tra quyền Admin.
    Chỉ cho phép Admin truy cập vào route.
    """
    def wrapper(*args, **kwargs):
        if 'user_role' not in session or session['user_role'] != 'Admin':
            flash("Access denied. Admins only.", "danger")
            return redirect(url_for('user_bp.login'))
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

@user_bp.route('/register', methods=['GET', 'POST'])
def register():
    """
    Đăng ký tài khoản mới.
    """
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        email = request.form.get('email')
        role = request.form.get('role', 'Customer')  # Mặc định là 'Customer'

        # Tạo user mới
        user_id = add_user(username, password, email, role)
        if user_id is None:
            error_msg = "Registration failed! (Username may already exist)."
            return render_template('user/register.html', error=error_msg)
        else:
            # Tự động đăng nhập sau khi đăng ký
            session['user_id'] = user_id
            session['user_role'] = role
            return redirect(url_for('user_bp.profile'))
    return render_template('user/register.html')

@user_bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    Đăng nhập.
    """
    if request.method == 'POST':
        username = request.form.get('username')
        password_input = request.form.get('password')

        user = get_user_by_username(username)
        if user:
            # Kiểm tra mật khẩu
            if verify_password(password_input, user['password']):
                # Đăng nhập thành công
                session['user_id'] = user['id']
                session['user_role'] = user['role']  # Lưu vai trò vào session
                flash("Login successful!", "success")
                return redirect(url_for('menu_bp.list_menus'))
            else:
                flash("Invalid username or password.", "danger")
        else:
            flash("Invalid username or password.", "danger")
    return render_template('user/login.html')

@user_bp.route('/logout')
def logout():
    """
    Đăng xuất.
    """
    session.pop('user_id', None)
    session.pop('user_role', None)
    flash("Logged out successfully!", "info")
    return redirect(url_for('user_bp.login'))

@user_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    """
    Hiển thị thông tin hồ sơ của người dùng và cho phép thay đổi avatar.
    """
    if 'user_id' not in session:
        return redirect(url_for('user_bp.login'))

    user_id = session['user_id']
    user = get_user_by_id(user_id)
    if not user:
        return "User not found", 404

    if request.method == 'POST':
        # Xử lý upload avatar
        avatar_file = request.files.get('avatar')
        if avatar_file and avatar_file.filename:
            upload_folder = 'static/uploads/avatars'
            avatar_filename = f"user_{user_id}_{avatar_file.filename}"
            avatar_file.save(f"{upload_folder}/{avatar_filename}")

            # Cập nhật avatar trong DB
            from model.user_model import update_user_avatar
            update_user_avatar(user_id, avatar_filename)

            flash("Avatar updated successfully!", "success")
            return redirect(url_for('user_bp.profile'))

    return render_template('user/profile.html', user=user)

@user_bp.route('/admin_dashboard')
@admin_required
def admin_dashboard():
    """
    Dashboard chỉ dành cho Admin.
    """
    return render_template('admin/dashboard.html')
