import os
from flask import Blueprint, render_template, request, redirect, url_for, current_app, session, flash
from model.menu_model import (
    add_menu,
    get_all_menus,
    get_menu_by_id,
    update_menu,
    delete_menu,
    search_menus_by_name
)

menu_bp = Blueprint('menu_bp', __name__)

@menu_bp.route('/')
def list_menus():
    """
    Display the menu list with optional search functionality.
    """
    query = request.args.get('q', '').strip()
    items = search_menus_by_name(query) if query else get_all_menus()
    return render_template('menu/list.html', menus=items)


@menu_bp.route('/create', methods=['GET', 'POST'])
def create_menu_item():
    """
    Create a new menu item with optional image upload.
    """
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        price = request.form.get('price', '0').strip()
        description = request.form.get('description', '').strip()

        # Handle image upload
        image_file = request.files.get('image')
        image_filename = None
        if image_file and image_file.filename:
            upload_folder = current_app.config['UPLOAD_FOLDER']
            image_filename = image_file.filename
            save_path = os.path.join(upload_folder, image_filename)
            image_file.save(save_path)

        # Add menu to the database
        try:
            add_menu(name, float(price), description, image_filename)
            flash("Menu item created successfully.", "success")
        except Exception as e:
            flash(f"Error creating menu item: {e}", "danger")
        return redirect(url_for('menu_bp.list_menus'))

    return render_template('menu/form.html', action='create')


@menu_bp.route('/<int:menu_id>')
def detail_menu_item(menu_id):
    """
    Display details of a specific menu item.
    """
    menu_item = get_menu_by_id(menu_id)
    if not menu_item:
        flash("Menu item not found.", "danger")
        return redirect(url_for('menu_bp.list_menus'))
    return render_template('menu/detail.html', item=menu_item)


@menu_bp.route('/<int:menu_id>/edit', methods=['GET', 'POST'])
def edit_menu_item(menu_id):
    """
    Edit an existing menu item with optional image upload.
    """
    menu_item = get_menu_by_id(menu_id)
    if not menu_item:
        flash("Menu item not found.", "danger")
        return redirect(url_for('menu_bp.list_menus'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        price = request.form.get('price', '0').strip()
        description = request.form.get('description', '').strip()

        # Handle image upload
        image_file = request.files.get('image')
        image_filename = None
        if image_file and image_file.filename:
            upload_folder = current_app.config['UPLOAD_FOLDER']
            os.makedirs(upload_folder, exist_ok=True)
            image_filename = image_file.filename
            save_path = os.path.join(upload_folder, image_filename)
            image_file.save(save_path)

        # Update menu item
        try:
            update_menu(menu_id, name, float(price), description, image=image_filename)
            flash("Menu item updated successfully.", "success")
        except Exception as e:
            flash(f"Error updating menu item: {e}", "danger")
        return redirect(url_for('menu_bp.list_menus'))

    return render_template('menu/form.html', action='edit', item=menu_item)


@menu_bp.route('/<int:menu_id>/delete', methods=['POST'])
def delete_menu_item(menu_id):
    """
    Delete a specific menu item.
    """
    if delete_menu(menu_id):
        flash("Menu item deleted successfully.", "success")
    else:
        flash("Failed to delete menu item.", "danger")
    return redirect(url_for('menu_bp.list_menus'))


@menu_bp.route('/<int:menu_id>/buy', methods=['POST'])
def buy_menu_item(menu_id):
    """
    Thêm sản phẩm vào giỏ hàng.
    """
    # Lấy sản phẩm từ database
    menu_item = get_menu_by_id(menu_id)
    if not menu_item:
        flash("Sản phẩm không tồn tại!", "danger")
        return redirect(url_for('menu_bp.list_menus'))

    # Đảm bảo giỏ hàng tồn tại trong session
    cart = session.get('cart', [])
    
    # Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
    for item in cart:
        if item['id'] == menu_item['id']:
            item['quantity'] += 1  # Tăng số lượng nếu đã có
            session['cart'] = cart
            flash(f"Đã cập nhật số lượng của {menu_item['name']} trong giỏ hàng.", "success")
            return redirect(url_for('menu_bp.list_menus'))

    # Thêm sản phẩm mới vào giỏ hàng
    cart.append({
        'id': menu_item['id'],
        'name': menu_item['name'],
        'price': menu_item['price'],
        'quantity': 1
    })
    session['cart'] = cart
    flash(f"Đã thêm {menu_item['name']} vào giỏ hàng.", "success")
    return redirect(url_for('menu_bp.list_menus'))

@menu_bp.route('/cart')
def view_cart():
    """
    Hiển thị nội dung giỏ hàng.
    """
    cart = session.get('cart', [])
    
    # Đảm bảo mỗi item trong cart có đầy đủ các key: 'id', 'name', 'price', 'quantity'
    valid_cart = []
    for item in cart:
        if all(key in item for key in ['id', 'name', 'price', 'quantity']):
            valid_cart.append(item)
        else:
            print(f"Invalid item removed from cart: {item}")  # Debug log (tùy chọn)
    
    # Cập nhật lại cart sau khi loại bỏ phần tử không hợp lệ
    session['cart'] = valid_cart
    
    # Tính tổng
    total = sum(item['price'] * item['quantity'] for item in valid_cart)
    return render_template('menu/cart.html', cart=valid_cart, total=total)

@menu_bp.route('/cart/remove/<int:item_id>', methods=['POST'])
def remove_from_cart(item_id):
    """
    Xóa sản phẩm khỏi giỏ hàng.
    """
    cart = session.get('cart', [])
    new_cart = [item for item in cart if item['id'] != item_id]  # Loại bỏ sản phẩm theo `id`
    
    if len(new_cart) < len(cart):
        flash("Đã xóa sản phẩm khỏi giỏ hàng.", "success")
    else:
        flash("Sản phẩm không tồn tại trong giỏ hàng.", "danger")
    
    session['cart'] = new_cart
    return redirect(url_for('menu_bp.view_cart'))
