from flask import Blueprint, session, redirect, url_for, render_template, flash, request
from model.menu_model import get_menu_by_id  # Import hàm để lấy sản phẩm từ DB

cart_bp = Blueprint('cart_bp', __name__)

@cart_bp.route('/')
def view_cart():
    """
    Hiển thị giỏ hàng.
    """
    cart = session.get('cart', [])
    total = sum(item['price'] * item['quantity'] for item in cart) if cart else 0
    return render_template('cart/cart.html', cart=cart, total=total)

@cart_bp.route('/add/<int:menu_id>', methods=['POST'])
def add_to_cart(menu_id):
    """
    Thêm sản phẩm vào giỏ hàng.
    """
    # Lấy thông tin sản phẩm từ cơ sở dữ liệu
    menu_item = get_menu_by_id(menu_id)
    if not menu_item:
        flash("Product not found.", "danger")
        return redirect(url_for('menu_bp.list_menus'))

    # Kiểm tra xem giỏ hàng đã tồn tại chưa
    if 'cart' not in session:
        session['cart'] = []

    cart = session['cart']

    # Kiểm tra sản phẩm đã có trong giỏ hàng chưa
    for item in cart:
        if item['id'] == menu_id:
            item['quantity'] += 1
            session['cart'] = cart
            flash(f"Updated quantity of {menu_item['name']} in cart.", "success")
            return redirect(url_for('cart_bp.view_cart'))

    # Thêm sản phẩm mới vào giỏ hàng
    cart.append({
        'id': menu_item['id'],
        'name': menu_item['name'],
        'price': menu_item['price'],
        'quantity': 1
    })
    session['cart'] = cart
    flash(f"Added {menu_item['name']} to cart.", "success")
    return redirect(url_for('cart_bp.view_cart'))

@cart_bp.route('/remove/<int:item_id>', methods=['POST'])
def remove_from_cart(item_id):
    """
    Xóa sản phẩm khỏi giỏ hàng.
    """
    cart = session.get('cart', [])
    cart = [item for item in cart if item['id'] != item_id]
    session['cart'] = cart
    flash("Item removed from the cart.", "success")
    return redirect(url_for('cart_bp.view_cart'))

cart_bp.route('/update-quantity/<int:item_id>', methods=['POST'])
def update_quantity(item_id):
    """
    Cập nhật số lượng sản phẩm trong giỏ hàng.
    """
    new_quantity = int(request.form.get('quantity', 1))
    cart = session.get('cart', [])

    for item in cart:
        if item['id'] == item_id:
            if new_quantity > 0:
                item['quantity'] = new_quantity
                flash(f"Updated quantity of {item['name']} to {new_quantity}.", "success")
            else:
                cart.remove(item)  # Xóa item nếu số lượng là 0
                flash(f"Removed {item['name']} from cart.", "info")
            break

    session['cart'] = cart
    return redirect(url_for('cart_bp.view_cart'))
