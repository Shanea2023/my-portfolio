import os
from flask import Flask, render_template, session, redirect, url_for

# Import các blueprint từ controller
from controller.user_controller import user_bp
from controller.menu_controller import menu_bp
from controller.search_controller import search_bp
from controller.cart_controller import cart_bp  # Blueprint giỏ hàng
from controller.order_controller import order_bp  # Blueprint quản lý order


def create_app():
    app = Flask(__name__)
    
    # Bảo mật session, thay đổi khi deploy thật
    app.secret_key = "my-secret-key"
    
    # Cấu hình thư mục để upload ảnh (VD: ảnh menu)
    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/uploads')
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)  # Đảm bảo thư mục tồn tại
    
    # Tùy chọn: giới hạn kích thước file upload (VD: 16 MB)
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB

    # Đăng ký blueprint cho các tính năng
    app.register_blueprint(user_bp, url_prefix='/user')    # Quản lý người dùng
    app.register_blueprint(menu_bp, url_prefix='/menu')    # Quản lý menu
    app.register_blueprint(search_bp, url_prefix='/search') # Chức năng tìm kiếm
    app.register_blueprint(cart_bp, url_prefix='/cart')    # Quản lý giỏ hàng
    app.register_blueprint(order_bp, url_prefix='/order')  # Quản lý order

    @app.route('/')
    def home():
        """
        Trang chủ.
        """
        # Nếu là admin, chuyển hướng đến trang quản lý đơn hàng
        if session.get('user_role') == 'Admin':  # Kiểm tra vai trò người dùng
            return redirect(url_for('order_bp.manage_orders'))
        return render_template('home.html')

    @app.errorhandler(404)
    def not_found_error(error):
        """
        Xử lý lỗi 404.
        """
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        """
        Xử lý lỗi 500.
        """
        return render_template('errors/500.html'), 500

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
