import sqlite3

DB_PATH = "database.db"

def ensure_users_table():
    """
    Đảm bảo bảng 'users' tồn tại với đầy đủ các cột (id, username, password, email, role).
    Nếu thiếu cột 'email' hoặc 'role', tự động thêm bằng ALTER TABLE.
    """
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # 1) Tạo bảng nếu chưa tồn tại
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT,
            role TEXT DEFAULT 'Customer'
        );
    ''')
    conn.commit()
    print("Đã kiểm tra (và tạo nếu cần) bảng 'users'.")

    # 2) Thêm các cột bị thiếu
    missing_columns = []
    
    # Kiểm tra cấu trúc bảng để tìm các cột bị thiếu
    c.execute("PRAGMA table_info(users);")
    existing_columns = {col[1] for col in c.fetchall()}  # Lấy tên các cột hiện tại

    if "email" not in existing_columns:
        try:
            c.execute("ALTER TABLE users ADD COLUMN email TEXT;")
            missing_columns.append("email")
        except sqlite3.OperationalError as e:
            print("Lỗi khi thêm cột 'email':", e)

    if "role" not in existing_columns:
        try:
            c.execute("ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'Customer';")
            missing_columns.append("role")
        except sqlite3.OperationalError as e:
            print("Lỗi khi thêm cột 'role':", e)

    if missing_columns:
        print(f"Đã thêm các cột sau vào bảng 'users': {', '.join(missing_columns)}")
    else:
        print("Không cần thêm cột nào, bảng 'users' đã đầy đủ.")

    conn.commit()
    conn.close()
    print("Hoàn tất kiểm tra và đảm bảo bảng 'users'.")


def check_users_table():
    """
    Hiển thị cấu trúc và nội dung bảng 'users' (nếu có).
    """
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Lấy thông tin cấu trúc bảng
    try:
        print("\nCấu trúc bảng 'users':")
        c.execute("PRAGMA table_info(users);")
        columns = c.fetchall()
        for col in columns:
            print(f" - {col[1]} ({col[2]})")  # col[1]: tên cột, col[2]: kiểu dữ liệu
    except Exception as e:
        print("Lỗi khi kiểm tra cấu trúc bảng 'users':", e)

    # Lấy dữ liệu trong bảng (nếu có)
    try:
        print("\nDữ liệu trong bảng 'users':")
        c.execute("SELECT * FROM users;")
        rows = c.fetchall()
        if rows:
            for row in rows:
                print(row)
        else:
            print("(Bảng rỗng)")
    except Exception as e:
        print("Lỗi khi kiểm tra dữ liệu bảng 'users':", e)

    conn.close()


if __name__ == "__main__":
    # Chạy đảm bảo bảng 'users' đúng cấu trúc
    ensure_users_table()

    # Kiểm tra cấu trúc và dữ liệu bảng 'users'
    print("\n--- Kiểm tra trạng thái bảng 'users' ---")
    check_users_table()
